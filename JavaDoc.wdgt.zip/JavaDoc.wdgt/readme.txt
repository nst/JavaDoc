FAQ
---

1. How do I add my own Java documentation in the search path�?
   -----------------------------------------------------------

   Add your own path in the config file�:
   
   ~/Library/Preferences/ch.seriot.widget.JavaDoc.plist
   
      <string>/System/Library/Frameworks/JavaVM.framework/Versions/1.4.2/Resources/Documentation/Reference/doc/api/</string>      <string>/Users/nst/my_own_path/</string>
      <string>/Users/nst/bla bla bla/</string>
      <string>~/another_path/</string>
   
2. Does JavaDoc care about the case�?
   ----------------------------------

   No, as cmd-F do not.

3. I have two classes with the same name in different packages.
   ------------------------------------------------------------

   JavaDoc does not allow you to choose the package in that case.
   It's in the TODO list.

4. Where does it look for the documentation�?
   ------------------------------------------
   
   JavaDoc parses the doc in�:
   
        /System/Library/Frameworks/JavaVM.framework/Versions/1.6.0/Resources/Documentation/Reference/doc/api/
        /System/Library/Frameworks/JavaVM.framework/Versions/1.5.1/Resources/Documentation/Reference/doc/api/
        /System/Library/Frameworks/JavaVM.framework/Versions/1.4.2/Resources/Documentation/Reference/doc/api/
   
   which is the default location on Tiger.
   
5. Java 1.5 is installed, but JavaDoc can't find the documentation.
   ----------------------------------------------------------------
   
   You can download and install a local version of the documentation from:
   
        http://connect.apple.com/

6. Where can I find new versions�?
   -------------------------------
   
   New versions are posted on http://seriot.ch/JavaDoc
   
   You can leave comments, feature requests and bug reports.

Nicolas Seriot, 2006.10.18
